export default {
	show_errors: 'interaction',
	max_depth: 16,
	use_default_values: true,
	remove_empty_properties: true,
	remove_false_properties: false,
	template: 'default',	// template engine name
	callbacks: {
		autocomplete: {
		},
		template: {
		},
		upload: {
		}
	}
};
