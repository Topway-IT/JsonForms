<?php
/**
 * Aliases for the JsonForms extension
 *
 * @file
 * @ingroup Extensions
 */
$specialPageAliases = [];

/**
 * English
 */
$specialPageAliases['en'] = [
	'JsonFormsDemo' => [ 'JsonFormsDemo' ],
	'JsonFormsManage' => [ 'JsonFormsManage' ]
];
