# JsonForms

Json-schema compliant form manager. Includes a no DOM-manipulation refactor of https://github.com/json-editor/json-editor

Please check https://www.mediawiki.org/wiki/Extension:JsonForms for the official documentation.

