/**
 * This file is part of the MediaWiki extension JsonForms.
 *
 * JsonForms is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * JsonForms is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with JsonForms. If not, see <http://www.gnu.org/licenses/>.
 *
 * @file
 * @author thomas-topway-it <support@topway.it>
 * @copyright Copyright ©2025-2026, https://wikisphere.org
 */

function JsonForms() {
	this.moduleCache = new Map();
	this.formDescriptor = {};
	this.editorOptions = {};
	this.jsoneditor = null;
	this.outerEditor = null;
}

// Fetch all page titles in a given namespace
// Fetch all page titles in a given namespace (without namespace prefix)
const getTitlesInNamespace = (nsId) => {
	let cache = null;
	let pending = null;

	return async () => {
		if (cache) return cache;
		if (pending) return pending;

		const api = new mw.Api();

		pending = api
			.get({
				action: 'query',
				list: 'allpages',
				apnamespace: nsId,
				aplimit: 'max',
				formatversion: 2,
			})
			.then((res) => {
				cache = res.query.allpages.map((page) => {
					const titleObj = new mw.Title(page.title);
					const baseTitle = titleObj.getMainText();
					return {
						text: baseTitle,
						value: baseTitle,
					};
				});
				pending = null;
				return cache;
			});

		return pending;
	};
};

JsonForms.prototype.getTitlesInNamespace = function (nsId) {
	let cache = null;
	let pending = null;

	return async () => {
		if (cache) return cache;
		if (pending) return pending;

		const api = new mw.Api();

		pending = api
			.get({
				action: 'query',
				list: 'allpages',
				apnamespace: nsId,
				aplimit: 'max',
				formatversion: 2,
			})
			.then((res) => {
				cache = res.query.allpages.map((page) => {
					const titleObj = new mw.Title(page.title);
					const baseTitle = titleObj.getMainText();
					return {
						text: baseTitle,
						value: baseTitle,
					};
				});
				pending = null;
				return cache;
			});

		return pending;
	};
};

JsonForms.prototype.submitForm = function () {
	console.log('this.jsoneditor.editors', this.jsoneditor.editors);

	const editors = {};
for (let path in this.jsoneditor.editors) {
    let editor = this.jsoneditor.editors[path];


console.log('editor',editor)
console.log('editor.isPrimitive()',editor.isPrimitive())
	if ( 'activeIndex' in editor ) {
		editor = editor.editors[editor.activeIndex]
	}


    if (editor.isPrimitive() && editor.value !== undefined) {
        const cleanPath = path.replace(/^root\./, '');
        let parent = editor.parent;

        // Walk up to skip switch wrappers
        while (parent && parent.switcher) {
            parent = parent.parent;
        }

        // Check if parent's parent is an array
        let isArrayValue = false;
        if (parent && parent.parent && parent.parent.schema?.type === 'array') {
            isArrayValue = true;
        }

        editors[cleanPath] = {
            value: editor.getValue(),
            schema: editor.schema,
            pathNoIndex: editor.pathNoIndex.replace(/^root\./, ''),
            isArrayValue,
        };
    }
}


	const data = {
		value: this.jsoneditor.getValue(),
		editors,
	};

	const outerEditor =
		this.outerEditor.getEditor('root.form.options') ||
		this.outerEditor.getEditor('root.form.form.options');

	const formData = outerEditor.getValue();

	console.log('data', data);
	console.log('formData', formData);

	var payload = {
		data: JSON.stringify(data),
		form: JSON.stringify(formData),
		action: 'jsonforms-submit-form',
	};

	// console.log('payload', payload);
	return new Promise((resolve, reject) => {
		new mw.Api()
			.postWithToken('csrf', payload)
			.done(function (thisRes) {
				console.log('thisRes', thisRes);
			})
			.fail(function (thisRes) {
				// eslint-disable-next-line no-console
				console.error('jsonforms-submit-form', thisRes);
				reject(thisRes);
			});
	});
};

JsonForms.prototype.UIFormEditorOptions = function () {
	return {
		show_errors: 'interaction',
		template: 'default',
		max_depth: 16,
		use_default_values: true,
		remove_empty_properties: false,
		remove_false_properties: false,
		callbacks: {
			template: {
				schemaEnumSource: async () => {
					const fetchFn = this.getTitlesInNamespace(2100);
					return await fetchFn();
				},
				schemaEnumFilter: (jseditor, { item }) => {
					return true;
				},
				schemaEnumTitle: (jseditor, { item }) => item.text,
				schemaEnumValue: (jseditor, { item }) => item.value,
			},

			button: {
				outerFormNavButton: (editor) => {
					console.log('editor', editor);
					const formEditor =
						'root.form.form' in editor.jsoneditor.editors
							? editor.jsoneditor.editors['root.form.form']
							: editor.jsoneditor.editors['root.form'];
					const booklet = formEditor.editor_holder.layout;
					console.log('booklet', booklet);
					switch (editor.key) {
						case 'submit':
							{
								this.submitForm();
							}
							break;
						case 'goback':
							booklet.setPage('main');
							break;
						case 'validate':
							{
								const res = editor.jsoneditor.getValue();
								console.log('res', res);

								// the inner editor
								if (this.jsoneditor.validation_results.length === 0) {
									booklet.setPage('options');
								}
							}

							break;
					}
				},
			},
		},
	};
};

// @see KnowledgeGraph.js
JsonForms.prototype.getModule = async function (str) {
	if (this.moduleCache.has(str)) {
		return this.moduleCache.get(str);
	}

	try {
		const module = await import(`data:text/javascript;base64,${btoa(str)}`);
		const result = module.default ?? null;
		this.moduleCache.set(str, result);
		return result;
	} catch (err) {
		console.error('Failed to load module:', err);
		return null;
	}
};

// @credits https://medium.com/javascript-inside/safely-accessing-deeply-nested-values-in-javascript-99bf72a0855a
JsonForms.prototype.getNestedProp = function (path, obj) {
	return path.reduce((xs, x) => (xs && xs[x] ? xs[x] : null), obj);
};

JsonForms.prototype.removeArrayItem = function (arr, value) {
	const index = arr.indexOf(value);
	if (index !== -1) {
		arr.splice(index, 1);
	}
};

JsonForms.prototype.adjustOptionsSchema = function (targetSchema) {
	const result = structuredClone(targetSchema);
	return result;
	result.properties.options.properties = {};

	for (const [key, field] of Object.entries(
		targetSchema.properties.options.properties,
	)) {
		const keyMap = {
			categories: 'edit_categories',
			wikitext: 'edit_wikitext',
			slot: 'edit_slot',
			content_model: 'edit_content_model',
		};

		if (keyMap[key] && !this.formDescriptor[keyMap[key]]) {
			result.properties.options.required =
				result.properties.options.required.filter((k) => k !== key);
			continue;
		}

		result.properties.options.properties[key] = field;
	}

	// remove schema select if schema is defined
	if (this.formDescriptor.schema) {
		delete result.properties.schema.properties.schema;
		this.removeArrayItem(result.properties.schema.required, 'schema');
	}

	if (this.formDescriptor.pagename_formula || this.formDescriptor.edit_page) {
		delete result.properties.options.properties.title;
		this.removeArrayItem(result.properties.options.required, 'title');
	}

	if (!this.formDescriptor.edit_wikitext) {
		delete result.properties.options.properties.content_model;
		this.removeArrayItem(result.properties.options.required, 'content_model');
	}

	return result;
};


JsonForms.prototype.uniqueID = function () {
		return Math.random().toString( 16 ).slice( 2 );
	}
	
JsonForms.prototype.createEditor = function (config) {
	$(config.el).html('');

	JSONEditor.defaults.options = config.editorOptions || {};

	const editor = new JSONEditor(config.el, {
		theme: 'oojs',
		schema: config.schema,
		schemaName: config.schemaName,
		uiSchema: config.uiSchema,
		startval: config.startVal,
		// partialSchema: 'options',
		// show_errors: 'change',
		ajax: true,
		ajaxUrl: function (ref, fileBase) {
			const mwBaseUrl = mw.config.get('wgServer') + mw.config.get('wgScript');

			// console.log(' ajaxUrl fileBase', fileBase);
			// console.log(' ajaxUrl mwBaseUrl', mwBaseUrl);

			if (fileBase.indexOf(mwBaseUrl) === -1) {
				return ref;
			}

			return `${mwBaseUrl}?title=${ref}&action=raw&uid=${this.uniqueID}`;
		},
	});

	const textarea = $('<textarea>', {
		class: 'form-control',
		id: 'value',
		rows: 12,
		style: 'font-size: 12px; font-family: monospace;',
	});

	$(config.el).append(textarea);

	editor.on('change', () => {
		textarea.val(JSON.stringify(editor.getValue(), null, 2));
	});

	editor.on('ready', () => {});

	return editor;
};

JsonForms.prototype.loadSchema = function (schemaName) {
	if (!schemaName) {
		return Promise.reject('No schema name provided');
	}
	if (schemaName === 'undefined') {
		return Promise.reject('invalid name');
	}

	return new Promise((resolve, reject) => {
		fetch(mw.util.getUrl(`JsonSchema:${schemaName}`, { action: 'raw' }), {
			cache: 'no-store',
		})
			.then((res) => res.text())
			.then((text) => {
				try {
					const json = JSON.parse(text);
					resolve(json);
				} catch (error) {
					console.log('schemaName', schemaName);
					console.log('text', text);
					console.error('Failed to parse schema JSON:', error);
					reject(error);
				}
			})
			.catch((fetchError) => {
				console.error('Failed to fetch schema:', fetchError);
				reject(fetchError);
			});
	});
};

JsonForms.prototype.reloadSchema = function () {
	let editor_ = this.outerEditor.getEditor('root.schema');
	const schemaName = editor_.getValue();

	// console.log('schemaName', schemaName);

	if (!schemaName) {
		console.log('no schemaName');
		return;
	}

	const placeholderEditor = this.outerEditor.getEditor(
		'root.form.form.placeholder',
	);
	// console.log('schemaEditor', schemaEditor);

	editor_ = this.outerEditor.getEditor('root.uischema');
	let uiSchemaName;

	if (editor_) {
		uiSchemaName = editor_.getValue();
	}

	if (!editor_ || !uiSchemaName) {
		this.loadSchema(schemaName).then((schema) => {
			this.jsoneditor = this.createEditor({
				schemaName,
				schema,
				// startVal,
				el: placeholderEditor.container,
				editorOptions: this.editorOptions,
			});
		});

		return;
	}

	this.loadSchema(uiSchemaName).then((uiSchema) => {
		this.loadSchema(schemaName).then((schema) => {
			this.jsoneditor = this.createEditor({
				schemaName,
				schema,
				uiSchema,
				// startVal,
				el: placeholderEditor.container,
				editorOptions: this.editorOptions,
			});
		});
	});
};

JsonForms.prototype.getUISchema = function () {
	const contentModels = mw.config.get('jsonforms')['contentModels'];
	const contentModelsKeys = Object.keys(contentModels);
	const contentModelsNames = Object.values(contentModels);

	const schema = {
		type: 'object',
		options: {
			compact: true,
			cssClass: 'jsonforms-outerform',
		},
		required: ['form', 'buttons'],
		properties: {
			form: {
				type: 'object',
				options: {
					compact: true,
					cssClass: 'jsonforms-innerform',
					layout: {
						name: 'booklet',
						config: {
							outlined: false,
						},
					},
				},
				properties: {
					placeholder: {
						type: 'null',
						format: 'info',
					},
					options: {
						type: 'object',
						options: {
							compact: true,
						},
						properties: {
							title: {
								type: 'string',
								options: { input: { name: 'title' } },
							},

							// target slot for json data
							slot: {
								type: 'string',
								description: 'Target slot for form data',
								default: this.formDescriptor.default_slot,
								enum: ['main', ...mw.config.get('jsonforms')['jsonSlots']],
							},
							// content model of main slot,
							// only if target slot is different than main
							// and wikitext is enabled
							content_model: {
								title: 'content model of main slot',
								// description: 'content model of main slot',
								type: 'string',
								default: 'wikitext',
								enum: contentModelsKeys,
								options: {
									enum_titles: contentModelsNames,
									dependencies: {
										slot: { op: '!=', value: 'main' },
									},
								},
							},
							wikitext: {
								type: 'string',
								format: 'textarea',
								options: {
									dependencies: {
										slot: { op: '!=', value: 'main' },
									},
								},
							},
							categories: {
								type: 'array',
								items: {
									type: 'string',
									options: { input: { name: 'categorymultiselect' } },
								},
							},
							summary: { type: 'string' },
						},
						required: [],
					},
				},
			},
			buttons: {
				options: {
					compact: true,
					cssClass: 'jsonforms-outerform-buttons',
				},
				properties: {
					validate: {
						type: 'null',
						format: 'button',
						options: {
							input: {
								config: {},
							},
							button: {
								action: 'outerFormNavButton',
							},
						},
					},
					submit: {
						type: 'null',
						format: 'button',
						options: {
							input: {
								config: { flags: ['primary', 'progressive'] },
							},
							button: {
								action: 'outerFormNavButton',
							},
						},
					},
					goback: {
						type: 'null',
						format: 'button',
						options: {
							config: {},
							button: {
								action: 'outerFormNavButton',
							},
						},
					},
				},
			},
		},
	};

	return this.adjustOptionsSchema(schema);
};

JsonForms.prototype.getUISchemaSpecial = function () {
	return {
		type: 'object',
		options: {
			cssClass: 'jsonforms-outerform',
			compact: true,
		},
		properties: {
			schema: {
				type: 'string',
				default: '',
				enumSource: [
					{
						source: 'schemaEnumSource',
						filter: 'schemaEnumFilter',
						title: 'schemaEnumTitle',
						value: 'schemaEnumValue',
					},
				],
			},
			/*
		uischema: {
			type: 'string',
			enum: schemas,
			default: '',
		},
		*/
			form: this.getUISchema(),
		},
	};
};

JsonForms.prototype.init = async function (el, schemas) {
	const data = $(el).data();

	$(el).html('');

	// console.log('data', data);
	this.formDescriptor = data.formData.formDescriptor;
	const schema = data.formData.schema;
	const schemaName = data.formData.schemaName;
	const startVal = data.formData.data;
	const editorOptionsStr = data.formData.editorOptions;

	console.log('editorOptionsStr', editorOptionsStr);

	this.editorOptions = await this.getModule(editorOptionsStr);

	// console.log('myModule', myModule);

	// console.log('formDescriptor', formDescriptor);
	// console.log('schema', schema);

	// const optionsHolder = $(el).append('<div>');
	// const schemaHolder = $(el).append('<div>');

	const outerschema = Object.keys(schema).length
		? this.getUISchema()
		: this.getUISchemaSpecial();

	this.outerEditor = this.createEditor({
		schemaName: 'Form',
		el,
		schema: outerschema,
		editorOptions: this.UIFormEditorOptions(),
	});

	if (schema && Object.keys(schema).length) {
		this.outerEditor.on('ready', () => {
			editor =
				this.outerEditor.getEditor('root.form.placeholder') ||
				this.outerEditor.getEditor('root.form.form.placeholder');

			if (editor) {
				this.jsoneditor = this.createEditor({
					schemaName,
					el: editor.container,
					schema,
					startVal,
					editorOptions: this.editorOptions,
				});
			}
		});

		return;
	}

	this.outerEditor.on('ready', () => {
		this.outerEditor.watch('root.schema', () => {
			this.reloadSchema();
		});

		this.outerEditor.watch('root.uischema', () => {
			this.reloadSchema();
		});
	});
};

$(function () {
	const schemas = mw.config.get('jsonforms-schemas');
	// console.log('schemas', schemas);
	console.log(' mw.config', mw.config);

	$('.jsonforms-form-wrapper').each(function (index, el) {
		const jsonForms = new JsonForms();
		jsonForms.init(el, schemas);
	});
});

