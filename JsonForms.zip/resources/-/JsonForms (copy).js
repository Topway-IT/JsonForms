/**
 * This file is part of the MediaWiki extension JsonForms.
 *
 * JsonForms is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * JsonForms is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with JsonForms. If not, see <http://www.gnu.org/licenses/>.
 *
 * @file
 * @author thomas-topway-it <support@topway.it>
 * @copyright Copyright ©2025-2026, https://wikisphere.org
 */

JsonForms = function () {


	
// @see KnowledgeGraph.js
const moduleCache = new Map();

async function getModule(str) {
    if (moduleCache.has(str)) return moduleCache.get(str);

    try {
        const module = await import(`data:text/javascript;base64,${btoa(str)}`);
        const result = module.default ?? null;
        moduleCache.set(str, result);
        return result;
    } catch (err) {
        console.error('Failed to load module:', err);
        return null;
    }
}




	function removeArrayItem(arr, value) {
		const index = arr.indexOf(value);
		if (index !== -1) {
			arr.splice(index, 1);
		}
	}

	function buildFormSchema(targetSchema, descriptor) {
		const result = structuredClone(targetSchema);
		result.properties.options.properties = {};

		for (const [key, field] of Object.entries(
			targetSchema.properties.options.properties,
		)) {
			const keyMap = {
				categories: 'edit_categories',
				wikitext: 'edit_wikitext',
				slot: 'edit_slot',
				content_model: 'edit_content_model',
			};

			if (keyMap[key] && !descriptor[keyMap[key]]) {
				result.properties.options.required =
					result.properties.options.required.filter((k) => k !== key);
				continue;
			}

			result.properties.options.properties[key] = field;
		}

		// remove schema select if schema is defined
		if (descriptor.schema) {
			delete result.properties.schema.properties.schema;
			removeArrayItem(result.properties.schema.required, 'schema');
		}

		if (descriptor.pagename_formula || descriptor.edit_page) {
			delete result.properties.options.properties.title;
			removeArrayItem(result.properties.options.required, 'title');
		}

		if (!descriptor.edit_wikitext) {
			delete result.properties.options.properties.content_model;
			removeArrayItem(result.properties.options.required, 'content_model');
		}

		return result;
	}

	function createEditor(config) {
		$(config.el).html('');

		JSONEditor.defaults.callbacks.autocomplete = {
			// This is callback functions for the "autocomplete" editor
			// In the schema you refer to the callback function by key
			// Note: 1st parameter in callback is ALWAYS a reference to the current editor.
			// So you need to add a variable to the callback to hold this (like the
			// "jseditor_editor" variable in the examples below.)

			// Lookup using data from form
			search_local: function search(jseditor_editor, input) {
				var ed = jseditor_editor.jsoneditor.getEditor('root.possibleFonts');
				if (input.length < 1 || !ed) {
					return [];
				}
				const data = ed.getValue();
				return data.filter(function (item) {
					return item.toLowerCase().startsWith(input.toLowerCase());
				});
			},

			// Setup for DAWA lookup
			search_dawa: function search(jseditor_editor, input) {
				var url =
					'https://dawa.aws.dk/vejnavne/autocomplete?q=' + encodeURI(input);

				return new Promise(function (resolve) {
					if (input.length < 3) {
						return resolve([]);
					}

					fetch(url)
						.then(function (response) {
							return response.json();
						})
						.then(function (data) {
							resolve(data);
						});
				});
			},
			getResultValue_dawa: function getResultValue(jseditor_editor, result) {
				return result.tekst;
			},

			// Setup for Wikipedia lookup
			search_wikipedia: function search(jseditor_editor, input) {
				console.log('jseditor_editor', jseditor_editor);

				var url =
					'https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&origin=*&srsearch=' +
					encodeURI(input);

				return new Promise(function (resolve) {
					if (input.length < 3) {
						return resolve([]);
					}

					fetch(url)
						.then(function (response) {
							return response.json();
						})
						.then(function (data) {
							resolve(data.query.search);
						});
				});
			},
			getResultValue_wikipedia: function getResultValue(
				jseditor_editor,
				result,
			) {
				return result.title;
			},
			renderResult_wikipedia: function (jseditor_editor, result, props) {
				return [
					'<li ' + props + '>',
					'<div class="wiki-title">' + result.title + '</div>',
					'<div class="wiki-snippet"><small>' +
						result.snippet +
						'<small></div>',
					'</li>',
				].join('');
			},

			// Setup for restcountries.eu contries lookup
			search_restcountries: function search(jseditor_editor, input) {
				var url = 'https://restcountries.eu/rest/v2/name/' + encodeURI(input);

				return new Promise(function (resolve) {
					if (input.length < 3) {
						return resolve([]);
					}

					fetch(url)
						.then(function (response) {
							return response.json();
						})
						.then(function (data) {
							if (!Array.isArray(data)) data = [];
							resolve(data);
						});
				});
			},
			getResultValue_restcountries: function getResultValue(
				jseditor_editor,
				result,
			) {
				return result.name;
			},
			renderResult_restcountries: function (jseditor_editor, result, props) {
				return [
					'<li ' + props + '>',
					'<div class="countries-title">',
					'<span class="flag-icon flag-icon-' +
						result.alpha2Code.toLowerCase() +
						'"></span> ' +
						result.name +
						'</div>',
					'<div class="countries-snippet"><small>Capital: ' +
						result.capital +
						'<small></div>',
					'</li>',
				].join('');
			},
		};
console.log('config',config)
		const editor = new JSONEditor(config.el, {
			theme: 'oojs',
			schema: config.schema,
			schemaName: config.schemaName,
			uiSchema: config.uiSchema,
			startval: config.startVal,
			// partialSchema: 'options',
			// show_errors: 'change',
			ajax: true,
			ajaxUrl: function (ref, fileBase) {
				const mwBaseUrl = mw.config.get('wgServer') + mw.config.get('wgScript');

				// console.log(' ajaxUrl fileBase', fileBase);
				// console.log(' ajaxUrl mwBaseUrl', mwBaseUrl);

				if (fileBase.indexOf(mwBaseUrl) === -1) {
					return ref;
				}

				return `${mwBaseUrl}?title=${ref}&action=raw`;
			},
		});

		const textarea = $('<textarea>', {
			class: 'form-control',
			id: 'value',
			rows: 12,
			style: 'font-size: 12px; font-family: monospace;',
		});

		// $(config.el).append(textarea);

		editor.on('change', () => {
			textarea.val(JSON.stringify(editor.getValue(), null, 2));
		});

		editor.on('ready', () => {});

		return editor;
	}

	function loadSchema(schemaName) {
		if (!schemaName) return Promise.reject('No schema name provided');

		return new Promise((resolve, reject) => {
			fetch(mw.util.getUrl(`JsonSchema:${schemaName}`, { action: 'raw' }), {
				cache: 'no-store',
			})
				.then((res) => res.text())
				.then((text) => {
					try {
						const json = JSON.parse(text);
						resolve(json);
					} catch (error) {
						console.error('Failed to parse schema JSON:', error);
						reject(error);
					}
				})
				.catch((fetchError) => {
					console.error('Failed to fetch schema:', fetchError);
					reject(fetchError);
				});
		});
	}

	async function init(el, schemas) {
		const data = $(el).data();

		$(el).html('');

		// console.log('data', data);
		const formDescriptor = data.formData.formDescriptor;
		const schema = data.formData.schema;
		const schemaName = data.formData.schemaName;
		const startVal = data.formData.data;
		const editorOptionsStr = data.formData.editorOptions
		
		console.log('editorOptionsStr', editorOptionsStr);
		 
		 const editorOptions = await getModule(editorOptions);

		// console.log('myModule', myModule);




		// console.log('formDescriptor', formDescriptor);
		// console.log('schema', schema);

		// const optionsHolder = $(el).append('<div>');
		// const schemaHolder = $(el).append('<div>');

		const contentModels = mw.config.get('jsonforms')['contentModels'];
		const contentModelsKeys = Object.keys(contentModels);
		const contentModelsNames = Object.values(contentModels);

		const Outerschema = {
			type: 'object',
			options: {
				cssClass: 'jsonforms-outerform',
				layout: {
					name: 'booklet',
					config: {
						outlined: false,
					},
				},
				compact: true,
			},
			properties: {
				schema: {
					type: 'object',
					options: {
						compact: true,
					},
					properties: {
						schema: {
							type: 'string',
							enum: schemas,
							default: '',
						},
						/*
						uischema: {
							type: 'string',
							enum: schemas,
							default: '',
						},
					*/
						info: {
							type: 'info',
						},
						buttons: {
							options: {
								compact: true,
								cssClass: 'jsonforms-outerform-buttons',
							},
							properties: {
								validate: {
									type: 'null',
									format: 'button',
									options: {
										input: {
											config: { flags: ['primary', 'progressive'] },
										},
									},
								},
								submit: {
									type: 'null',
									format: 'button',
									options: {
										input: {
											config: { flags: ['primary', 'progressive'] },
										},
									},
								},
							},
						},
					},
					required: ['schema', 'info', 'buttons' ],
				},
				options: {
					type: 'object',
					options: {
						compact: true,
					},
					properties: {
						title: {
							type: 'string',
							options: { input: { name: 'title' } },
						},

						// target slot for json data
						slot: {
							type: 'string',
							description: 'Target slot for form data',
							default: formDescriptor.default_slot,
							enum: ['main', ...mw.config.get('jsonforms')['jsonSlots']],
						},
						// content model of main slot,
						// only if target slot is different than main
						// and wikitext is enabled
						content_model: {
							title: 'content model of main slot',
							// description: 'content model of main slot',
							type: 'string',
							default: 'wikitext',
							enum: contentModelsKeys,
							options: {
								enum_titles: contentModelsNames,
								dependencies: {
									slot: { op: '!=', value: 'main' },
								},
							},
						},
						wikitext: {
							type: 'string',
							format: 'textarea',
							options: {
								dependencies: {
									slot: { op: '!=', value: 'main' },
								},
							},
						},
						categories: {
							type: 'array',
							items: {
								type: 'string',
								options: { input: { name: 'categorymultiselect' } },
							},
						},
						summary: { type: 'string' },
						buttons: {
							options: {
								compact: true,
								cssClass: 'jsonforms-outerform-buttons',
							},
							properties: {
								submit: {
									type: 'null',
									format: 'button',
									options: {
										input: {
											config: { flags: ['primary', 'progressive'] },
										},
									},
								},
								goback: {
									type: 'null',
									format: 'button',
									options: {
										config: {},
									},
								},
							},
						},
					},
					required: ['title', 'slot', 'content_model', 'buttons' ],
				},
			},
			required: ['options', 'schema'],
		};

		console.log('formDescriptor', formDescriptor);
		console.log(
			'buildFormSchema(Outerschema, formDescriptor)',
			buildFormSchema(Outerschema, formDescriptor),
		);
		// console.log('Outerschema', Outerschema);

		const editor = createEditor({
			schemaName: 'Form',
			el,
			schema: buildFormSchema(Outerschema, formDescriptor),
		});

		if (schema && Object.keys(schema).length) {
			editor.on('ready', () => {
				editor_ = editor.getEditor('root.schema.info');

				if (editor_) {
					createEditor({ schemaName, el: editor_.container, schema, startVal });
				}
			});

			return;
		}

		function reloadSchema() {
			let editor_ = editor.getEditor('root.schema.schema');
			const schemaName = editor_.getValue();

			// console.log('schemaName', schemaName);

			if (!schemaName) {
				console.log('no schemaName');
				return;
			}

			const schemaEditor = editor.getEditor('root.schema.info');
			// console.log('schemaEditor', schemaEditor);

			editor_ = editor.getEditor('root.schema.uischema');
			let uiSchemaName;

			if (editor_) {
				uiSchemaName = editor_.getValue();
			}

			if (!editor_ || !uiSchemaName) {
				loadSchema(schemaName).then((schema) => {
					createEditor({
						schemaName,
						schema,
						startVal,
						el: schemaEditor.container,
					});
				});

				return;
			}

			loadSchema(uiSchemaName).then((uiSchema) => {
				loadSchema(schemaName).then((schema) => {
					createEditor({
						schemaName,
						schema,
						uiSchema,
						startVal,
						el: schemaEditor.container,
					});
				});
			});
		}

		editor.on('ready', () => {
			editor.watch('root.schema.schema', () => {
				reloadSchema();
			});

			editor.watch('root.schema.uischema', () => {
				reloadSchema();
			});
		});
	}

	return { init };
};

$(function () {
	const schemas = mw.config.get('jsonforms-schemas');
	// console.log('schemas', schemas);
	console.log(' mw.config', mw.config);

	$('.jsonforms-form-wrapper').each(function (index, el) {
		const jsonForms = new JsonForms();
		jsonForms.init(el, schemas);
	});



});

