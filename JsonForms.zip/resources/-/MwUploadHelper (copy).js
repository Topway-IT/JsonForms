
function MWUploadHelper() {}

MWUploadHelper.prototype.getFileExtension = function(name) {
    return name.includes('.') ? name.split('.').pop().toLowerCase() : '';
};

MWUploadHelper.prototype.validate = function(jseditor, file) {
    const allowedTypes = jseditor.schema?.options?.upload?.mime_type || [];
    const maxSize = jseditor.schema?.options?.upload?.max_upload_size;

    if (allowedTypes.length && !allowedTypes.includes(file.type)) {
        return `Invalid file type: ${file.type}. Allowed: ${allowedTypes.join(', ')}`;
    }
    if (maxSize && file.size > maxSize) {
        return `File too large (${file.size} bytes). Max allowed: ${maxSize} bytes.`;
    }
    return null;
};

MWUploadHelper.prototype.notifyError = function(msg) {
    if (typeof mw !== 'undefined' && mw.notify) {
        mw.notify(msg, { title: 'Upload Error', type: 'error' });
    } else {
        console.error(msg);
    }
};

MWUploadHelper.prototype.resolveTarget = function(jseditor, file) {
    const ext = this.getFileExtension(file.name);
    let target = `${Math.random().toString(36).slice(2)}.${ext}`;
    if (jseditor.value) target = jseditor.value.replace(/^File:/, '');
    return target;
};

MWUploadHelper.prototype.upload = function(file, target, cbs) {
    const api = new mw.Api();


    const formData = new FormData();
    formData.append('action', 'upload');
    formData.append('filename', target);
    formData.append('file', file);
    formData.append('format', 'json');
    formData.append('ignorewarnings', 1); 


const token = await new mw.Api().getToken('csrf');
formData.append('token', token);


    fetch(mw.config.get('wgScriptPath') + '/api.php', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
    })
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                const msg = `Upload failed: ${data.error.info}`;
                this.notifyError(msg);
                if (cbs.failure) cbs.failure(msg);
            } else {
                console.log(`File uploaded: ${target}`);
                if (cbs.success) cbs.success(target);
                // Fire a hook so other modules can react
                if (mw.hook) mw.hook('jsoneditor.file.uploaded').fire({ name: target, exists: true });
            }
        })
        .catch(err => {
            const msg = `Upload failed: ${err}`;
            this.notifyError(msg);
            if (cbs.failure) cbs.failure(msg);
        });
};



