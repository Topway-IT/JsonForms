function SmwAutocompleteHelper() {}

// ---------------------------------------------------
// Construct the SMW query based on user input
// ---------------------------------------------------
SmwAutocompleteHelper.prototype.buildQuery = function(jseditor_editor, input) {
	jseditor_editor.unhandled_input = true; // mark started input

	// Base query from schema
	let query = mwjson.schema.getAutocompleteQuery(jseditor_editor.schema, input);

	// Replace watched values in query
	for (const key in jseditor_editor.watched_values) {
		if (jseditor_editor.watched[key]) {
			query = query.replaceAll(
				'{{$(' + key + ')}}',
				'{{' + jseditor_editor.watched[key].replace("root.", "") + '}}'
			);
		}

		if (jseditor_editor.watched_values[key] === undefined) {
			query = query.replace('$(' + key + ')', encodeURIComponent('+'));
		}

		query = query.replaceAll('$(' + key + ')', jseditor_editor.watched_values[key]);
	}

	// Create augmented data for Handlebars
	const jsondata = mwjson.util.deepCopy(jseditor_editor.jsoneditor.getValue());
	jsondata['_user_input'] = input;
	jsondata['_user_input_lowercase'] = input.toLowerCase();
	jsondata['_user_input_normalized'] = mwjson.util.normalizeString(input);
	jsondata['_user_input_normalized_tokenized'] = mwjson.util.normalizeAndTokenizeString(input);
	jsondata['_user_lang'] = jseditor_editor.jsoneditor.options.user_language;

	// Compile Handlebars
	const template = Handlebars.compile(query);
	query = template(jsondata);

	// Detect UUID patterns and replace
	const uuid_regex = /([a-f0-9]{8})(_|-| |){1}([a-f0-9]{4})(_|-| |){1}([a-f0-9]{4})(_|-| |){1}([a-f0-9]{4})(_|-| |){1}([a-f0-9]{12})/gm;
	const matches = input.match(uuid_regex);
	if (matches && matches.length) {
		let uuidQuery = matches
			.map(match => "[[HasUuid::" + match.replace(uuid_regex, `$1-$3-$5-$7-$9`) + "]]OR")
			.join('');
		uuidQuery = uuidQuery.replace(/OR+$/, '');
		query = query.replace(query.split('|')[0], uuidQuery);
	}

	// Ensure limit
	if (!query.includes("|limit=")) query += "|limit=100";

	return query;
};

// ---------------------------------------------------
// Perform the SMW API request
// ---------------------------------------------------
SmwAutocompleteHelper.prototype.fetchResults = function(query, input) {
	const url = `${mw.config.get("wgScriptPath")}/api.php?action=ask&query=${query}&format=json`;

	return fetch(url)
		.then(res => res.json())
		.then(data => {
			let resultList = [];

			if (!data || data.error) {
				console.warn("SMW autocomplete error: ", data?.error);
			} else if (input === "") {
				// aborted input
			} else {
				const result_property = null; // Could compute based on schema if needed
				if (result_property && data.query?.results) {
					resultList = [];
					Object.values(data.query.results).forEach(result => {
						resultList = resultList.concat(result.printouts[result_property]);
					});
					resultList = [...new Set(resultList)];
				} else if (data.query?.results) {
					resultList = Object.values(data.query.results);
				}

				// Optional sorting by displaytitle
				resultList.sort((a, b) => input.length / b.displaytitle?.length - input.length / a.displaytitle?.length);
			}

			return resultList;
		});
};

// ---------------------------------------------------
// Render SMW result
// ---------------------------------------------------
SmwAutocompleteHelper.prototype.renderResult = function(jseditor_editor, result, props) {
	if (!result) return '';

	// Normalize multilanguage printouts
	const normalized = mwjson.util.normalizeSmwMultilangResult(result, jseditor_editor.jsoneditor.options.user_language);

	const previewTemplate = mwjson.util.deepCopy(
		mwjson.schema.getAutocompletePreviewTemplate(jseditor_editor.schema)
	);

	if (previewTemplate.type.shift() === 'handlebars') {
		if (previewTemplate.type[0] === 'wikitext') {
			previewTemplate.value = previewTemplate.value.replaceAll("\\{", "&#123;").replaceAll("\\}", "&#125;");
		}
		const template = Handlebars.compile(previewTemplate.value);
		previewTemplate.value = template({ result: normalized });
		if (previewTemplate.type[0] === 'wikitext') {
			previewTemplate.value = previewTemplate.value.replaceAll("&#123;", "{").replaceAll("&#125;", "}");
		}
	}

	return `<li ${props}>${previewTemplate.value}</li>`;
};

// ---------------------------------------------------
// Get label to display in editor
// ---------------------------------------------------
SmwAutocompleteHelper.prototype.getResultValue = function(jseditor_editor, result) {
	let label = result.displaytitle || result.fulltext;
	const labelTemplate = mwjson.util.deepCopy(
		mwjson.schema.getAutocompleteLabelTemplate(jseditor_editor.schema)
	);

	if (labelTemplate && labelTemplate.type.shift() === 'handlebars') {
		label = Handlebars.compile(labelTemplate.value)({ result });
	}

	return label;
};

// ---------------------------------------------------
// Handle selection
// ---------------------------------------------------
SmwAutocompleteHelper.prototype.onSubmit = function(jseditor_editor, result) {
	jseditor_editor.unhandled_input = false;

	let result_value = result.fulltext;
	const storeTemplate = mwjson.util.deepCopy(
		mwjson.schema.getAutocompleteStoreTemplate(jseditor_editor.schema)
	);

	if (storeTemplate && storeTemplate.type.shift() === 'handlebars') {
		result_value = Handlebars.compile(storeTemplate.value)({ result });
	}

	mwjson.util.setJsonEditorAutocompleteField(jseditor_editor, result_value, result.printouts?.label?.[0]);

	// Handle field_maps
	if (jseditor_editor.schema?.options?.autocomplete?.field_maps) {
		for (const map of jseditor_editor.schema.options.autocomplete.field_maps) {
			let value = mwjson.extData.getValue({ result }, map.source_path, "jsonpath");
			if (map.template) value = Handlebars.compile(map.template)(value);

			let target_editor = map.target_path;
			for (const key in jseditor_editor.watched_values) {
				target_editor = target_editor.replace('$(' + key + ')', jseditor_editor.watched[key]);
			}

			const editor = jseditor_editor.jsoneditor.editors[target_editor];
			if (editor) {
				const editor_type = editor.schema?.type;
				if (editor_type === "array" || editor_type === "object") {
					value = JSON.parse(value.replaceAll(/\n/g,'\\n'));
				}
				editor.setValue(value);
			}
		}
	}
};

