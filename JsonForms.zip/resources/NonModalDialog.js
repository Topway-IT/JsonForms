SimpleDialog = function(config) {
	SimpleDialog.super.call(this, config);
};
OO.inheritClass(SimpleDialog, OO.ui.Dialog);
SimpleDialog.static.title = 'Simple dialog';
SimpleDialog.prototype.initialize = function () {
	SimpleDialog.super.prototype.initialize.apply(this, arguments);
	this.content = new OO.ui.PanelLayout({ padded: true, expanded: false });
	// eslint-disable-next-line no-jquery/no-parse-html-literal
	this.content.$element.append('<p>Dialog content</p>');

	const closeButton = new OO.ui.ButtonWidget({
		label: OO.ui.msg('ooui-dialog-process-dismiss'),
	});
	closeButton.on('click', () => {
		this.close();
	});

	this.content.$element.append(closeButton.$element);
	this.$body.append(this.content.$element);
};
SimpleDialog.prototype.getBodyHeight = function () {
	return this.content.$element.outerHeight(true);
};

NonModalDialog = function (config) {};

NonModalDialog.prototype.open = function () {
	const manager = new OO.ui.WindowManager( {
		modal: false,
		classes: [ 'jsonforms-dialogs-non-modal' ]
	} );

	// REQUIRED: attach to DOM
	$( document.body ).append( manager.$element );

	const dialogConfig = {
	//	size: 'large'
	};

	const name = 'window_nonmodaldialog';
	const windows = {};
	windows[ name ] = new SimpleDialog( dialogConfig );

	manager.addWindows( windows );
	
	manager.openWindow( name );
};



NonModalDialog.prototype.open_ = function () {
	const nonModalWindowManager = new OO.ui.WindowManager({
		modal: false,
		classes: ['jsonforms-dialogs-non-modal'],
	});

	const dialogConfig = {
		size: 'large',
	};

	const name = 'window_nonmodaldialog';
	const manager = nonModalWindowManager;
	const windows = {};
	windows[name] = new SimpleDialog(config);
	manager.addWindows(windows);
	openButton.on(
		'click',
		OO.ui.bind(openDialog, this, name, example.data, manager),
	);
};

